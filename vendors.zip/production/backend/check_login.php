<?php
session_start();

// Check if the user is logged in

if (!isset($_SESSION['user_id'])) {
    // If not logged in, redirect to the login page
    header('Location: ../production/login.html');
    exit(); // Ensure that no further code is executed after the header
}
?>
